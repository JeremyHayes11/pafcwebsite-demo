<footer>
  <div class="wrap">
    <div class="foot-grid">
      <div>
        <img class="foot-logo" src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/logo.png' ); ?>" alt="<?php bloginfo( 'name' ); ?>" style="filter:brightness(0) invert(1); opacity:0.9;">
        <p style="color:rgba(255,255,255,0.6); font-size:13.5px; max-width:280px;">Global sourcing and direct delivery of pharmaceutical and veterinary raw materials across the Americas.</p>
      </div>
      <div>
        <h5>Company</h5>
        <a href="#about">About</a>
        <a href="#services">Services</a>
        <a href="#industries">Industries</a>
      </div>
      <div>
        <h5>Contact</h5>
        <a href="mailto:h.klug@pafc.ca">h.klug@pafc.ca</a>
      </div>
    </div>
    <div class="foot-bottom">
      <span>&copy; <?php echo esc_html( date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. All rights reserved.</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
