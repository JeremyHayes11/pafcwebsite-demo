<?php
/**
 * Pan-American Fine Chemicals theme functions
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function panamerican_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
    add_theme_support( 'custom-logo', array(
        'height'      => 60,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ) );

    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'panamerican' ),
        'footer'  => __( 'Footer Menu', 'panamerican' ),
    ) );
}
add_action( 'after_setup_theme', 'panamerican_setup' );

function panamerican_scripts() {
    // Google Fonts used by the approved design
    wp_enqueue_style(
        'panamerican-fonts',
        'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap',
        array(),
        null
    );

    wp_enqueue_style(
        'panamerican-style',
        get_stylesheet_uri(),
        array( 'panamerican-fonts' ),
        wp_get_theme()->get( 'Version' )
    );
}
add_action( 'wp_enqueue_scripts', 'panamerican_scripts' );

/**
 * Fallback menu if no "Primary Menu" has been assigned yet in
 * Appearance > Menus, so the site never shows a blank nav.
 */
function panamerican_fallback_menu() {
    echo '<div class="nav-links">';
    echo '<a href="' . esc_url( home_url( '/' ) ) . '">Home</a>';
    echo '<a href="#about">About</a>';
    echo '<a href="#services">Services</a>';
    echo '<a href="#industries">Industries</a>';
    echo '<a href="#contact">Contact</a>';
    echo '</div>';
}
