<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<nav>
  <div class="wrap">
    <div class="logo-mark">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
        <?php if ( has_custom_logo() ) : ?>
          <?php the_custom_logo(); ?>
        <?php else : ?>
          <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/logo-nav.png' ); ?>" alt="<?php bloginfo( 'name' ); ?>">
        <?php endif; ?>
      </a>
    </div>

    <?php
    if ( has_nav_menu( 'primary' ) ) {
        wp_nav_menu( array(
            'theme_location' => 'primary',
            'container'      => 'div',
            'container_class'=> 'nav-links',
            'menu_class'     => 'nav-menu',
            'depth'          => 1,
        ) );
    } else {
        panamerican_fallback_menu();
    }
    ?>

    <div class="nav-cta">
      <a href="mailto:h.klug@pafc.ca" class="btn btn-primary" style="padding:18px 34px; font-size:19px;">Contact Us</a>
    </div>
  </div>
</nav>
