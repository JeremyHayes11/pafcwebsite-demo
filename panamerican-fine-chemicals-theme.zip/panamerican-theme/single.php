<?php get_header(); ?>

<section>
  <div class="wrap">
    <?php while ( have_posts() ) : the_post(); ?>
      <article <?php post_class(); ?>>
        <div class="section-head left">
          <h1><?php the_title(); ?></h1>
        </div>
        <div class="page-content">
          <?php the_content(); ?>
        </div>
      </article>
    <?php endwhile; ?>
  </div>
</section>

<?php get_footer(); ?>
