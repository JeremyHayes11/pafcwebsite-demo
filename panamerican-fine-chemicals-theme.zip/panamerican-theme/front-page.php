<?php get_header(); ?>

<section class="hero" id="home">
  <div class="hero-rings">
    <svg viewBox="0 0 400 400" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="ringGrad" x1="0" y1="0" x2="400" y2="400" gradientUnits="userSpaceOnUse">
          <stop offset="0" stop-color="#153F62"/>
          <stop offset="1" stop-color="#2FAFAA"/>
        </linearGradient>
      </defs>
      <circle cx="200" cy="150" r="120" stroke="url(#ringGrad)" stroke-width="2.5" opacity="0.55"/>
      <circle cx="230" cy="200" r="130" stroke="url(#ringGrad)" stroke-width="2.5" opacity="0.45"/>
      <circle cx="170" cy="230" r="115" stroke="url(#ringGrad)" stroke-width="2.5" opacity="0.5"/>
      <circle cx="200" cy="200" r="55" stroke="url(#ringGrad)" stroke-width="2" opacity="0.7"/>
    </svg>
  </div>
  <div class="wrap">
    <div class="hero-grid">
      <div>
        <div class="eyebrow">Global Sourcing &middot; Direct Delivery</div>
        <h1>Raw materials, sourced right and shipped <span>direct</span>.</h1>
        <p class="lead">Pan-American Fine Chemicals connects pharmaceutical and veterinary manufacturers across Asia, India and Europe with buyers throughout the Americas: one point of contact, one shipment, no unnecessary stops in between.</p>
        <div class="hero-actions">
          <a href="#services" class="btn btn-primary">Explore Our Services</a>
          <a href="mailto:h.klug@pafc.ca" class="btn btn-ghost">Talk to Our Team</a>
        </div>
        <div class="hero-stats">
          <div><b>10+</b><span>Years in international trade</span></div>
          <div><b>2</b><span>Core lines: human &amp; veterinary pharma</span></div>
          <div><b>1</b><span>Direct shipment, origin to destination</span></div>
        </div>
      </div>
      <div></div>
    </div>
  </div>
</section>

<section id="industries">
  <div class="wrap">
    <div class="section-head">
      <div class="eyebrow" style="justify-content:center;">What We Trade</div>
      <h2>Two industries. One standard of quality.</h2>
      <p>We supply active pharmaceutical ingredients (APIs) and excipients (the materials that bind and stabilize a formulation) to two distinct but equally demanding markets.</p>
    </div>
    <div class="lines">
      <div class="line-card human">
        <span class="tag">Human Pharma</span>
        <h3>Active ingredients &amp; excipients for human medicine</h3>
        <p>We supply active pharmaceutical ingredients (APIs) and excipients, the binding and processing agents used in powder blending, sourced from GMP-audited manufacturers across Asia, India and Europe for generic and branded drug production.</p>
        <ul>
          <li>Active Pharmaceutical Ingredients (APIs)</li>
          <li>Excipients &amp; blending agents</li>
          <li>Manufacturer vetting &amp; site audits</li>
        </ul>
      </div>
      <div class="line-card vet">
        <span class="tag">Veterinary Pharma</span>
        <h3>Raw materials for animal health &amp; feed producers</h3>
        <p>The same active pharmaceutical ingredients (APIs) and excipients, the binding and processing agents used in powder blending, applied to the veterinary and animal nutrition supply chain with the same sourcing discipline and quality controls.</p>
        <ul>
          <li>Veterinary APIs</li>
          <li>Feed-grade excipients</li>
          <li>Regulatory documentation support</li>
        </ul>
      </div>
    </div>
  </div>
</section>

<section id="how-it-works">
  <div class="wrap">
    <div class="flow">
      <div class="flow-inner">
        <div class="section-head left">
          <div class="eyebrow">How It Works</div>
          <h2>One direct shipment. One point of contact.</h2>
          <p>No unnecessary intermediary stops. Your order moves straight from the manufacturer to you, while we handle the work in between.</p>
        </div>
        <div class="flow-steps">
          <div class="flow-step">
            <span class="n">Origin</span>
            <h4>Manufacturer</h4>
            <p>Asia, India or Europe: GMP-certified production site</p>
          </div>
          <div class="flow-arrow">&#8594;</div>
          <div class="flow-step">
            <span class="n">In Between</span>
            <h4>Pan-American Fine Chemicals</h4>
            <p>Issues invoice &amp; packing list, routes payment, manages compliance</p>
          </div>
          <div class="flow-arrow">&#8594;</div>
          <div class="flow-step">
            <span class="n">Destination</span>
            <h4>Your Facility</h4>
            <p>Delivered directly, anywhere in the Americas</p>
          </div>
        </div>
        <div class="flow-note">Product documentation stays consistent end to end. The only new paperwork is our invoice and packing list.</div>
      </div>
    </div>
  </div>
</section>

<section id="services">
  <div class="wrap">
    <div class="section-head">
      <div class="eyebrow" style="justify-content:center;">Services</div>
      <h2>Everything around the shipment, handled.</h2>
    </div>
    <div class="services-grid">
      <div class="service">
        <div class="ic">&#9670;</div>
        <h4>Sourcing &amp; Consolidation</h4>
        <p>One consolidated shipment instead of managing multiple suppliers and freight forwarders.</p>
      </div>
      <div class="service">
        <div class="ic">&#9989;</div>
        <h4>Regulatory Support</h4>
        <p>Assistance with registration paperwork and manufacturer site audits before you commit.</p>
      </div>
      <div class="service">
        <div class="ic">&#128176;</div>
        <h4>Financing</h4>
        <p>Flexible credit terms available depending on your credentials and financial background.</p>
      </div>
      <div class="service">
        <div class="ic">&#9875;</div>
        <h4>Logistics</h4>
        <p>Air, sea and local delivery routes, matched to your timeline and product type.</p>
      </div>
      <div class="service">
        <div class="ic">&#128269;</div>
        <h4>Quality &amp; Compliance</h4>
        <p>Every manufacturer vetted against GMP and destination-market regulatory requirements.</p>
      </div>
      <div class="service">
        <div class="ic">&#128101;</div>
        <h4>A Human Point of Contact</h4>
        <p>Direct access to our team throughout, not a ticketing queue.</p>
      </div>
    </div>
  </div>
</section>

<section id="about">
  <div class="wrap">
    <div class="about">
      <div class="about-visual">
        <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/hans-photo.jpg' ); ?>" alt="Hans Klug">
        <div class="cap">Hans Klug, Founder</div>
      </div>
      <div>
        <div class="eyebrow">Who We Are</div>
        <h2>Trade built on relationships, not just transactions.</h2>
        <p class="about-quote">"Service, the human factor, comes first."</p>
        <p>With over a decade of experience in international pharmaceutical and veterinary trade, we understand that every country has its own regulatory expectations, and every shipment carries real consequences if it's handled carelessly. That's why we stay close to both sides of the transaction: the manufacturer and the customer.</p>
        <p>We're a small, hands-on team by design, so when you call, you reach someone who already knows your order.</p>
      </div>
    </div>
  </div>
</section>

<section id="contact">
  <div class="wrap">
    <div class="cta">
      <div class="eyebrow" style="justify-content:center;">Get In Touch</div>
      <h2>Have a raw material need across the Americas?</h2>
      <p style="max-width:480px; margin:0 auto 8px;">Tell us what you're sourcing and where it needs to go and we'll respond with next steps.</p>
      <a href="mailto:h.klug@pafc.ca" class="btn btn-primary">Request a Quote</a>
    </div>
  </div>
</section>

<?php get_footer(); ?>
